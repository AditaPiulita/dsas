# frozen_string_literal: true

module ThemeCheck
  module ShopifyLiquid
    class SourceIndex
      class FilterState < BaseState
        @up_to_date = false
      end
    end
  end
end
