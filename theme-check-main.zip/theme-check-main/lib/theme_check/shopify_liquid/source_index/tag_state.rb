# frozen_string_literal: true

module ThemeCheck
  module ShopifyLiquid
    class SourceIndex
      class TagState < BaseState
        @up_to_date = false
      end
    end
  end
end
