# frozen_string_literal: true
module ThemeCheck
  VERSION = "1.15.0"
end
